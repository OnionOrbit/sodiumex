* Fixed crash on NeoForge
